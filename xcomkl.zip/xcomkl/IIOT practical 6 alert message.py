import RPi.GPIO as GPIO
import time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


SMTP_SERVER = 'smtp.gmail.com' 
SMTP_PORT = 587 
SMTP_USERNAME = 'sstisgaonkar371122@kkwagh.edu.in'  
SMTP_PASSWORD = 'SarthakKKWagh'  
EMAIL_FROM = 'sstisgaonkar371122@kkwagh.edu.in'  
EMAIL_TO = 'shreeyanpatil02@gmail.com'  
EMAIL_SUBJECT = 'Object Detected!'


IR_SENSOR_PIN = 7
LED_PIN = 11 


GPIO.setmode(GPIO.BOARD)
GPIO.setup(IR_SENSOR_PIN, GPIO.IN)
GPIO.setup(LED_PIN, GPIO.OUT)

def send_email():
    try:
        # Create a secure SSL context
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)

        # Email content
        message = MIMEMultipart()
        message['From'] = EMAIL_FROM
        message['To'] = EMAIL_TO
        message['Subject'] = EMAIL_SUBJECT
        body = "An object has been detected by the IR sensor."
        message.attach(MIMEText(body, 'plain'))

        # Send email
        server.sendmail(EMAIL_FROM, EMAIL_TO, message.as_string())

        # Clean up
        server.quit()
        print("Email sent successfully!")

    except Exception as e:
        print(f"Failed to send email: {e}")

try:
    while True:
        if GPIO.input(IR_SENSOR_PIN) == GPIO.HIGH:
            print("Object detected!")
            GPIO.output(LED_PIN, GPIO.HIGH)  # Turn on LED
            send_email()  # Send email notification
            time.sleep(1)  # Delay to avoid multiple emails in quick succession
        else:
            print("No object detected.")
            GPIO.output(LED_PIN, GPIO.LOW)  # Turn off LED
        
        time.sleep(0.5)

except KeyboardInterrupt:
    print("\nExiting program.")
finally:
    GPIO.cleanup()




This Python script uses the GPIO and email libraries to set up an infrared (IR) sensor on a Raspberry Pi that detects objects. When an object is detected, it triggers an LED and sends an email notification. Here’s a breakdown of the code:

### Key Code Sections and Explanation

#### 1. Import Required Libraries
```python
import RPi.GPIO as GPIO
import time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
```
- **RPi.GPIO**: Allows control of the Raspberry Pi's GPIO pins.
- **time**: Manages delays in the program.
- **smtplib**: Handles sending emails through an SMTP server.
- **email.mime**: Provides classes to structure email content.

#### 2. Define Email Server and Account Details
```python
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
SMTP_USERNAME = 'sstisgaonkar371122@kkwagh.edu.in'  
SMTP_PASSWORD = 'SarthakKKWagh'  
EMAIL_FROM = 'sstisgaonkar371122@kkwagh.edu.in'  
EMAIL_TO = 'shreeyanpatil02@gmail.com'  
EMAIL_SUBJECT = 'Object Detected!'
```
- **SMTP_SERVER** and **SMTP_PORT**: Specifies Gmail’s SMTP server.
- **SMTP_USERNAME** and **SMTP_PASSWORD**: Login credentials for the sender’s email (for Gmail, consider using an app-specific password if two-factor authentication is enabled).
- **EMAIL_FROM** and **EMAIL_TO**: Defines the sender and recipient email addresses.
- **EMAIL_SUBJECT**: Sets the subject of the email.

#### 3. Setup GPIO Pins
```python
IR_SENSOR_PIN = 7
LED_PIN = 11
GPIO.setmode(GPIO.BOARD)
GPIO.setup(IR_SENSOR_PIN, GPIO.IN)
GPIO.setup(LED_PIN, GPIO.OUT)
```
- **IR_SENSOR_PIN** and **LED_PIN**: Defines the GPIO pins connected to the IR sensor and LED.
- **GPIO.setmode(GPIO.BOARD)**: Sets the GPIO numbering mode.
- **GPIO.setup**: Configures the sensor as an input and the LED as an output.

#### 4. Define the `send_email` Function
```python
def send_email():
    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)

        message = MIMEMultipart()
        message['From'] = EMAIL_FROM
        message['To'] = EMAIL_TO
        message['Subject'] = EMAIL_SUBJECT
        body = "An object has been detected by the IR sensor."
        message.attach(MIMEText(body, 'plain'))

        server.sendmail(EMAIL_FROM, EMAIL_TO, message.as_string())
        server.quit()
        print("Email sent successfully!")

    except Exception as e:
        print(f"Failed to send email: {e}")
```
- **server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)**: Establishes an SMTP connection.
- **server.starttls()**: Secures the connection.
- **server.login**: Authenticates with the provided credentials.
- **MIMEMultipart**: Structures the email, with the subject, sender, recipient, and message body.
- **server.sendmail**: Sends the email.

#### 5. Main Loop for Object Detection
```python
try:
    while True:
        if GPIO.input(IR_SENSOR_PIN) == GPIO.HIGH:
            print("Object detected!")
            GPIO.output(LED_PIN, GPIO.HIGH)
            send_email()
            time.sleep(1)
        else:
            print("No object detected.")
            GPIO.output(LED_PIN, GPIO.LOW)
        
        time.sleep(0.5)

except KeyboardInterrupt:
    print("\nExiting program.")
finally:
    GPIO.cleanup()
```
- **while True**: Runs an infinite loop for continuous object detection.
- **GPIO.input(IR_SENSOR_PIN) == GPIO.HIGH**: Checks if the IR sensor detects an object.
- **GPIO.output(LED_PIN, GPIO.HIGH)**: Turns on the LED if an object is detected.
- **send_email()**: Sends an email notification when an object is detected.
- **time.sleep(1)**: Pauses briefly to avoid sending multiple emails in a short period.

### Important Considerations
1. **Email Security**: Avoid hard-coding sensitive credentials. Store them securely or use environment variables.
2. **GPIO Cleanup**: Ensures all GPIO pins are reset properly after the program exits.
3. **Delay Timing**: Adjust `time.sleep(0.5)` or `time.sleep(1)` to manage detection frequency and avoid spamming emails.

This setup can be useful for projects where remote object detection alerts are required, such as security or monitoring systems.


In simple terms, a program for sending alert messages is designed to monitor specific conditions or activities and notify the user whenever certain thresholds or events occur. This kind of system is used in real-time monitoring to help people respond to changes in their environment quickly and efficiently. 

### 1. **Core Components**
   - **Sensors or Data Sources**: Sensors (like temperature, motion, or smoke detectors) or other sources of data (like online servers or databases) continuously monitor the environment. For instance, a motion sensor can detect if someone enters a restricted area.
   - **Logic to Process Data**: The program has a set of predefined conditions. When the input data meets or exceeds these conditions, it "triggers" an alert. This logic could be simple (e.g., if temperature > 50°C, send an alert) or more complex (e.g., combining data from multiple sensors).
   - **Alert System**: The program is connected to an alert system that sends messages. This could be via SMS, email, a mobile app, or even activating a warning light or sound alarm.

### 2. **How It Works Step-by-Step**
   - **Step 1: Monitoring** – The program continuously monitors the conditions using sensors or by fetching data at regular intervals.
   - **Step 2: Detecting Changes** – When a specific condition is met, like the detection of a high temperature, a specific value is reached (e.g., pollution level exceeds safe limits), or an object is detected by a camera, the program identifies this change.
   - **Step 3: Sending Alerts** – After detecting a change, the program sends a notification to inform users about the situation. For example, an email or SMS notification could be sent to a security team if someone unauthorized enters an area.
   - **Step 4: User Response** – The user receives the message and can take action accordingly, like adjusting the temperature remotely, turning on or off devices, or contacting others to respond to the event.

### 3. **Real-Life Examples**
   - **Home Security System**: Imagine a security camera or a motion detector installed at your front door. When it detects movement, it sends an alert to your phone via an app or SMS so you can check the feed and decide if it's a delivery or something unusual.
   - **Smart Thermostat**: In smart homes, a thermostat can send an alert if the temperature gets too high or low. For instance, if you’re away and the temperature drops below a certain point, it might notify you to prevent pipes from freezing.
   - **Industrial Equipment Monitoring**: In factories, machines are equipped with sensors that monitor temperature, vibrations, or other metrics. If a machine’s vibration exceeds safe levels, the program alerts a technician so they can perform maintenance and avoid costly breakdowns.
   - **Environmental Monitoring**: In environmental protection, sensors track pollution levels in water or air. When pollution levels are too high, the program alerts authorities so they can take action to prevent health risks.

### 4. **Benefits of Alert Systems**
   - **Quick Response**: Alert systems help users respond quickly, which can prevent problems from escalating.
   - **Remote Monitoring**: They allow users to monitor situations remotely, which is useful for people who are not always on-site.
   - **Automated Control**: Some alert systems are combined with automation, so instead of just sending a message, they might also trigger a system response, like turning off equipment when an issue is detected.

Alert systems are an essential part of modern technology, helping us stay informed, react faster, and even prevent issues before they become serious.